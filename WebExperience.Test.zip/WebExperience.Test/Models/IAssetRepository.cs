﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebExperience.Test.Models
{
    public interface IAssetRepository
    {
        IEnumerable<AssetModel> GetAll();
        AssetModel Get(int id);
        AssetModel Add(AssetModel item);
        void Remove(int id);
        bool Update(AssetModel item);
    }
}