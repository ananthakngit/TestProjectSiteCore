﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebExperience.Test.Models
{
    public class AssetRepository:IAssetRepository
    {
        private List<AssetModel> assetModels = new List<AssetModel>();
        private int _nextId = 1;

        public AssetRepository()
        {
            Add(new AssetModel { title = "Tomato soup", created = "Groceries"});
            Add(new AssetModel { title = "Yo-yo", created = "Toys"});
            Add(new AssetModel { title = "Hammer", created = "Hardware" });
        }

        public IEnumerable<AssetModel> GetAll()
        {
            return assetModels;
        }

        public AssetModel Get(int id)
        {
            return assetModels.Find(p => p.Id == id);
        }

        public AssetModel Add(AssetModel item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            item.Id = _nextId++;
            assetModels.Add(item);
            return item;
        }

        public void Remove(int id)
        {
            assetModels.RemoveAll(p => p.Id == id);
        }

        public bool Update(AssetModel item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            int index = assetModels.FindIndex(p => p.Id == item.Id);
            if (index == -1)
            {
                return false;
            }
            assetModels.RemoveAt(index);
            assetModels.Add(item);
            return true;
        }
    }
}