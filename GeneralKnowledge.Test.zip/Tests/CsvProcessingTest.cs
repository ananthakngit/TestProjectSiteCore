﻿using System.Data;
using System.IO;

namespace GeneralKnowledge.Test.App.Tests
{
    /// <summary>
    /// CSV processing test
    /// </summary>
    public class CsvProcessingTest : ITest
    {
        public void Run()
        {
            // TODO
            // Create a domain model via POCO classes to store the data available in the CSV file below
            // Objects to be present in the domain model: Asset, Country and Mime type
            // Process the file in the most robust way possible
            // The use of 3rd party plugins is permitted

            var csvFile = Resources.AssetImport;

            //Read the contents of CSV file.
           // string csvData = File.ReadAllText(csvFile);

            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[7] 
            { new DataColumn("asset id", typeof(string)),
              new DataColumn("file_name", typeof(string)),
              new DataColumn("mime_type", typeof(string)),
               new DataColumn("created_by", typeof(string)),
                new DataColumn("email", typeof(string)),
                 new DataColumn("country", typeof(string)),
              new DataColumn("description",typeof(string)) });            

            //Execute a loop over the rows.
            foreach (string row in csvFile.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;

                    //Execute a loop over the columns.
                    foreach (string cell in row.Split(','))
                    {
                        try
                        {
                            dt.Rows[dt.Rows.Count - 1][i] = cell;
                            i++;
                        }
                        catch (System.Exception)
                        {

                           
                        }
                       
                    }
                }
            }

            var s = dt;
        }
    }

}
