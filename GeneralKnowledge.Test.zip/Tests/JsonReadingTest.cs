﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;

namespace GeneralKnowledge.Test.App.Tests
{
    /// <summary>
    /// Basic data retrieval from JSON test
    /// </summary>
    public class JsonReadingTest : ITest
    {
        public string Name { get { return "JSON Reading Test"; } }

        public void Run()
        {
            var jsonData = Resources.SamplePoints;

            // TODO: 
            // Determine for each parameter stored in the variable below, the average value, lowest and highest number.
            // Example output
            // parameter   LOW AVG MAX
            // temperature   x   y   z
            // pH            x   y   z
            // Chloride      x   y   z
            // Phosphate     x   y   z
            // Nitrate       x   y   z

            Encoding enc8 = Encoding.UTF8;

            var jsondata = enc8.GetString(jsonData);
            var parsjondata = JObject.Parse(jsondata);
            var res = JsonConvert.DeserializeObject<dynamic>(jsondata);
            List<Points> pointsLst = JsonConvert.DeserializeObject<List<Points>>(parsjondata["samples"].ToString());

            List <PrintOverviewPoints> pOverview = new List<PrintOverviewPoints>();

            PrintOverviewPoints overViewPoint;

            overViewPoint = new PrintOverviewPoints();
            overViewPoint.max = pointsLst.Select(p => p.temperature).AsQueryable().Max();
            overViewPoint.min= pointsLst.Select(p => p.temperature).AsQueryable().Min();
            overViewPoint.avg = pointsLst.Select(p => p.temperature).AsQueryable().Average();
            overViewPoint.param = "temperature";
            pOverview.Add(overViewPoint);


            overViewPoint = new PrintOverviewPoints();
            overViewPoint.max = pointsLst.Select(p => p.pH).AsQueryable().Max();
            overViewPoint.min = pointsLst.Select(p => p.pH).AsQueryable().Min();
            overViewPoint.avg = pointsLst.Select(p => p.pH).AsQueryable().Average();
            overViewPoint.param = "pH";
            pOverview.Add(overViewPoint);

            overViewPoint = new PrintOverviewPoints();
            overViewPoint.max = pointsLst.Select(p => p.chloride).AsQueryable().Max();
            overViewPoint.min = pointsLst.Select(p => p.chloride).AsQueryable().Min();
            overViewPoint.avg = pointsLst.Select(p => p.chloride).AsQueryable().Average();
            overViewPoint.param = "Chloride";

            pOverview.Add(overViewPoint);

            overViewPoint = new PrintOverviewPoints();
            overViewPoint.max = pointsLst.Select(p => p.phosphate).AsQueryable().Max();
            overViewPoint.min = pointsLst.Select(p => p.phosphate).AsQueryable().Min();
            overViewPoint.avg = pointsLst.Select(p => p.phosphate).AsQueryable().Average();
            overViewPoint.param = "Phosphate";

            pOverview.Add(overViewPoint);

            overViewPoint = new PrintOverviewPoints();
            overViewPoint.max = pointsLst.Select(p => p.nitrate).AsQueryable().Max();
            overViewPoint.min = pointsLst.Select(p => p.nitrate).AsQueryable().Min();
            overViewPoint.avg = pointsLst.Select(p => p.nitrate).AsQueryable().Average();
            overViewPoint.param = "Nitrate";

            pOverview.Add(overViewPoint);



            foreach (var item in pointsLst)
            {

            }

            PrintOverview(pOverview);
        }

        private void PrintOverview(List<PrintOverviewPoints> data)
        {
        }
    }



    public class Points
    {
        public decimal temperature { get; set; }
        public decimal pH { get; set; }
        public decimal phosphate { get; set; }
        public decimal chloride { get; set; }
        public decimal nitrate { get; set; }
        public string date { get; set; }

    }

    public class PrintOverviewPoints
    {
        public string param { get; set; }
        public decimal min { get; set; }
        public decimal max { get; set; }
        public decimal avg { get; set; }
        
    }
}